EnergyFront V3.5 - Public validation package (October 2026, revised 24 October 2026: ASHRAE 140 cases 640 and 940,
see Section 3 of the report)

01_Report                           Validation and Testing Report (PDF): what was tested, the results,
                                    the known limitations and the tests still to be done. Start here.
02_ASHRAE140_cases                  ASHRAE Standard 140-2020 envelope cases 600 to 650, 900 to 950 and the
                                    free-floating cases: results table (CSV) and the EnergyFront projects (*.json).
                                    Open a project in EnergyFront, choose the weather file of the Standard
                                    (725650TYCST.epw, not included) and run it to repeat the case.
03_HVAC_BESTEST_and_example_files   Results tables (CSV): HVAC BESTEST CE100/CE200, Furnace BESTEST HE100/HE230,
                                    and 47 example files of EnergyPlus 9.4 opened in EnergyFront and run again.
04_Licences                         EnergyPlus licence notice.

EnergyFront prepares input files for EnergyPlus 9.4 and presents its results. The results depend on EnergyPlus,
on the weather data and on the inputs entered by the user. EnergyFront has not been certified or approved by
ASHRAE, the U.S. Department of Energy or any rating authority. The tests listed do not cover every use of the
software; a feature or use that is not listed among the limitations is not thereby validated, and any use outside
the tested scope is at the user's responsibility. The scope and known limitations in the report form part of
the licence agreement (EULA) of EnergyFront, Section 9.5: https://www.archoptech.com/Terms
The results are information about the stated version, cases and conditions, not a warranty that the results
for any building are accurate. Results must be checked by a qualified professional before they are relied on.

EnergyPlus is a trademark of the U.S. Department of Energy. EnergyFront is not affiliated with or endorsed by the
U.S. Department of Energy. ASHRAE Standard 140 is referred to by name; the Standard, its weather file and the
reference input files are not included.
